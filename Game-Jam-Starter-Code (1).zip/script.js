/* VARIABLES */
//bg
let images = [];
let currentImageIndex  = 0;
let timer = 0;
//signs
let welcome;
//buttons
let begin;
//cats
let cats1;
let cats2;
let showBackground = true;
let catcher, fallingObject;
let score = 0;

//collection game
/* PRELOAD LOADS FILES */
function preload(){
  //bgs
images[0] = loadImage("bg1.png");
images[1] = loadImage("bg2.png");
images[2] = loadImage("bg3.png");
images[3] = loadImage("bg4.png");

  //yoga studio
  yogaStudio = loadImage("yogaStudio.png");

  //welcome sign
  //welcome = loadImage("welcome.png");

  //buttons


  //cats
  cats1 = loadImage("cats1.png");
  cats2 = loadImage("cats2.png");
  
}

/* SETUP RUNS ONCE */
function setup() {
  createCanvas(400,400);
  //begin button

  welcome = createImg("welcome.png");
  welcome.position(0, 0); 
  welcome.size(350, 350); 
  

  
    begin = createImg("begin.png");
    begin.position(5, -50); 
    begin.size(400, 400); 

  begin.mousePressed(changeBG);
    begin.style('cursor', 'pointer');

  //Create catcher 
  catcher = new Sprite(200,300);
  catcher.image = "basket.png";
  catcher.scale = 0.3;
  catcher.rotationLock = true;

  //COLLECTIONS GAME
  //Create falling object
  fallingObject = new Sprite(100,0,10);
  fallingObject.image = "droplet.png";
  fallingObject.scale = 0.1;
  fallingObject.vel.y = 2;

}

/* DRAW LOOP REPEATS */
function draw() {
  

  //background & timer
  //background(images[currentImageIndex]);
  
  if (showBackground) {
    
   
    background(images[currentImageIndex]);
    timer++;
    if (timer > 60) {
      nextImage();
      timer = 0;
    }
  } else {
    welcome.hide();
    background(yogaStudio); 
    begin.position(-500, -500); 
    

    

    //Move the catcer
    catcher.moveTowards(mouse.x, 380, .1);

  

    //make sure the falling object returns to the top if it falls below the screen & also randomizes the starting position
    if(fallingObject.y >= height){
      fallingObject.y = 0;
      fallingObject.x = random(width);
      fallingObject.vel.y = random(1,5);
    }

    //move the catcher with arrow keys
    if(kb.pressing("left")){
      catcher.vel.x = -3;
    }else if (kb.pressing("right")){
      catcher.vel.x = 3;
    }else {
      catcher.vel.x = 0;
    }

    //Stop catcher at edges of screen
    if(catcher.x < 50){
      catcher.x=50;
    }else if (catcher.x > 350){
      catcher.x = 350;
    }

    //collect the fallingObject
    // In your draw() function where you handle collision detection
    if (fallingObject.collides(catcher)) {
      fallingObject.y = 0;
      fallingObject.x = random(width);
      fallingObject.vel.y = random(1, 5);
      fallingObject.direction = "down";
      score = score + 1;
    }


    //display the score 
    textSize(10);
    textFont('Palatino', 20);
    text("Score = " + score, 10, 30);
    
    
  }
  
  //welcome sign
  image(welcome, 0,0, 400, 300);



  image(cats1, 250,200, 200, 200);

  image(cats2, -20,200, 200, 200);

  //CONDITIONS 
  
}





/* FUNCTIONS */

function nextImage() {
  //change in the images in a loop
  currentImageIndex = (currentImageIndex + 1) % images.length;
}

function changeBackground() {
  background("pink");
}

function changeBG(){
  showBackground = false;
}